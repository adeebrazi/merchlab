# Adivasi Ecommerce – Next.js Version

Run:
```
npm install
npm run dev
```